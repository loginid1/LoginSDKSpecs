//
//  LoginSDK.h
//  LoginSDK
//
//  Created by PD on 2019-11-07.
//  Copyright © 2019 Loginid. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LoginSDK.
FOUNDATION_EXPORT double LoginSDKVersionNumber;

//! Project version string for LoginSDK.
FOUNDATION_EXPORT const unsigned char LoginSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LoginidSDK/PublicHeader.h>


